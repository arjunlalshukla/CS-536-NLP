test = {
  'name': '1.0',
  'points': 1,
  'suites': [
    {
      'cases': [
       
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
